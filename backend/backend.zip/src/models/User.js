const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    fullName: {
      type: String,
      required: true,
      trim: true,
      maxlength: 100,
    },

    nim: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      index: true,
    },

    username: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
      minlength: 3,
      maxlength: 30,
      index: true,
    },

    avatar: {
      type: String,
      default: null,
    },

    cover: {
      type: String,
      default: null,
    },

    bio: {
      type: String,
      default: "",
      maxlength: 300,
    },

    faculty: {
      type: String,
      default: null,
      trim: true,
    },

    major: {
      type: String,
      default: null,
      trim: true,
    },

    batchYear: {
      type: Number,
      default: null,
    },

    followersCount: {
      type: Number,
      default: 0,
      min: 0,
    },

    followingCount: {
      type: Number,
      default: 0,
      min: 0,
    },

    postsCount: {
      type: Number,
      default: 0,
      min: 0,
    },

    isVerified: {
      type: Boolean,
      default: false,
    },

    isPrivate: {
      type: Boolean,
      default: false,
    },

    lastSeenAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
    versionKey: false,
  }
);

userSchema.index({ username: 1 }, { unique: true });
userSchema.index({ nim: 1 }, { unique: true });

module.exports = mongoose.model("User", userSchema);