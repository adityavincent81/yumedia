const { ZodError } = require("zod");

const {
  errorResponse,
} = require("../utils/response");

const errorMiddleware = (
  err,
  req,
  res,
  next
) => {
  console.error(err);

  if (err instanceof ZodError) {
    return errorResponse(res, {
      statusCode: 400,
      message: "Validation failed",
      errors: err.flatten(),
    });
  }

  if (err.statusCode) {
    return errorResponse(res, {
      statusCode: err.statusCode,
      message: err.message,
      errors: err.errors || null,
    });
  }

  return errorResponse(res, {
    statusCode: 500,
    message: "Internal Server Error",
  });
};

module.exports = errorMiddleware;