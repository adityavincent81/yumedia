const User = require("../models/User");

class UserRepository {
  async create(payload) {
    return User.create(payload);
  }

  async findById(id) {
    return User.findById(id);
  }

  async findByUsername(username) {
    return User.findOne({ username });
  }

  async findByNim(nim) {
    return User.findOne({ nim });
  }

  async updateById(id, payload) {
    return User.findByIdAndUpdate(id, payload, {
      new: true,
      runValidators: true,
    });
  }
}

module.exports = new UserRepository();