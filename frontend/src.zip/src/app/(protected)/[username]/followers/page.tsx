import FollowersList from "@/components/follow/FollowersList";

interface FollowersPageProps {
  params: Promise<{
    username: string;
  }>;
}

export default async function FollowersPage({
  params,
}: FollowersPageProps) {
  const { username } =
    await params;

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold">
          Followers
        </h1>

        <p className="text-sm text-muted-foreground">
          @{username}
        </p>
      </div>

      <FollowersList
        followers={[]}
      />
    </div>
  );
}