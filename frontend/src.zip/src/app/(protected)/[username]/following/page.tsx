import FollowingList from "@/components/follow/FollowingList";

interface FollowingPageProps {
  params: Promise<{
    username: string;
  }>;
}

export default async function FollowingPage({
  params,
}: FollowingPageProps) {
  const { username } =
    await params;

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold">
          Following
        </h1>

        <p className="text-sm text-muted-foreground">
          @{username}
        </p>
      </div>

      <FollowingList
        following={[]}
      />
    </div>
  );
}