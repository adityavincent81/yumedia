import Link from "next/link";

interface ProfileStatsProps {
  username: string;

  postsCount: number;

  followersCount: number;

  followingCount: number;
}

export default function ProfileStats({
  username,
  postsCount,
  followersCount,
  followingCount,
}: ProfileStatsProps) {
  return (
    <div className="flex items-center gap-6">
      <div>
        <div className="font-semibold">
          {postsCount}
        </div>

        <div className="text-sm text-muted-foreground">
          Posts
        </div>
      </div>

      <Link
        href={`/${username}/followers`}
        className="text-left"
      >
        <div className="font-semibold">
          {followersCount}
        </div>

        <div className="text-sm text-muted-foreground">
          Followers
        </div>
      </Link>

      <Link
        href={`/${username}/following`}
        className="text-left"
      >
        <div className="font-semibold">
          {followingCount}
        </div>

        <div className="text-sm text-muted-foreground">
          Following
        </div>
      </Link>
    </div>
  );
}